import torch
print(torch.__version__) # PyTorch version
import torchvision
print(torchvision.__version__)

print(torch.version.cuda) # Corresponding CUDA version
print(torch.backends.cudnn.version()) # Corresponding cuDNN version
print(torch.cuda.get_device_name(0)) # GPU type
